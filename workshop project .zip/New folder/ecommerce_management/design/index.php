<?php require_once 'inc/header.php'; ?>     
    <h1 class="text-center p-3 border display-1">  Home Page  </h1>

    <div class="jumbotron">
        <h1 class="display-4"> Registration System </h1>
        <p class="lead">This is a simple hero unit, a simple jumbotron-style component for calling extra attention to featured content or information.</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
    </div>

    <!-- Optional JavaScript; choose one of the two! -->

<?php require_once 'inc/footer.php'; ?>     




