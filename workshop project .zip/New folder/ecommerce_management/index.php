<?php require_once 'app/config.php'; ?>
<?php getFile(FOLDER_PATH."app/database");   ?>
<?php getFile(FOLDER_PATH."inc/headerIndex");   ?>

    <h1 class="text-center borderd p-2 my-3"> Home Page </h1>

<?php include 'inc/footer.php'; ?>